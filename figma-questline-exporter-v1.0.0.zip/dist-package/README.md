# Figma Questline Theme Exporter

A Figma plugin for exporting questline themes with assets and positioning data.

## Installation Instructions

### For Designers:

1. **Download this folder** to your computer
2. **Open Figma**
3. **Go to Plugins** → **Development** → **Import plugin from manifest**
4. **Select the `manifest.json` file** from this folder
5. **The plugin will appear** in your "Development" plugins list

## How to Use

1. **Select a questline frame** (named "Questline: ...")
2. **Click "Scan Questline"** to analyze your design
3. **Review the results** and fix any issues shown
4. **Click "Export Assets"** to download images and data

## Features

- ✅ Scans questline frames for quest instances
- ✅ Validates quest keys and detects duplicates
- ✅ Exports all quest states (locked, closed, open)
- ✅ Creates ZIP file with images and positioning data
- ✅ User-friendly interface with error handling

## Support

For issues or questions, contact your development team.

## Version

v1.0.0 - Production Ready 